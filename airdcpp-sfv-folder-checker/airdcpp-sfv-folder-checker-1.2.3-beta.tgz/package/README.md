airdcpp-sfv-folder-checker (b1.2.1):

Hub command /sfvcheck <folder> that recursively checks a folder for .sfv
files and compares their CRC32 against the real files on disk. Works
together with airdcpp-release-fixxer.

•	/sfvcheck [folder] [full] — searches a folder (and subfolders) for .sfv files and checks the CRC32 of every listed file against what is actually on disk, using the real path (not the virtual share name).
        [folder] can also be set within the extension itself, in which case /sfvcheck without a path is enough.
        Add "full" (/sfvcheck [folder] full) to ignore the incremental cache and re-hash every file, regardless of modification date.
•	/sfvstop — cancels a running scan. The current file is still finished, after which the scan stops cleanly. Whatever has already been checked up to that point stays in the cache and the report.
•	Native CRC32 (via zlib, Node.js 21+) instead of a JS implementation — tens of times faster. On older Node versions the extension automatically falls back to a JS implementation; which path is active is reported in the system log when the extension starts.
•	Retry on stat/hash errors: automatically retried up to 3 times with a short pause in between before it's reported as a real problem.
•	Processes multiple release folders at once (configurable count, default 8). Files within 1 release folder are always hashed one after another; only different release folders run in parallel.
•	Incremental cache (configurable, on by default): remembers file size + modification date per file after a successful check, so unchanged files are skipped on the next /sfvcheck.
        NOTE: relies on the filesystem's modification date; bitrot that doesn't change it won't be caught. Run /sfvcheck [folder] full occasionally as an extra check.
•	Automatic cache cleanup: entries not seen for a configurable number of days (default 90) are removed after each scan. Set to 0 to disable.
•	After a scan in which files were deleted (CRC mismatch), the built-in AirDC++ "Optimize database" action is triggered once to clean up orphaned hash records. Can be turned off.
•	Progress messages in the system log during a scan (max. once every 5 sec.), indicating whether a file came from the cache.
•	JSON report per scan (in the extension's log folder) with all results, for airdcpp-release-fixxer to read.
•	Optional (on by default): automatically delete files with a CRC mismatch, so they can be redownloaded — applies to every mismatch, including ones that came from the cache.
•	As soon as a file is deleted, the extension searches for and downloads the corresponding release folder itself. Multiple deleted files from the same release folder within 1 scan only trigger 1 search. Searches happen one at a time with a configurable pause in between (default 15 sec.), using the lowest search priority (1) so manual searches/downloads always get sent to the hub first.
•	Right-click "Check SFV/CRC for this folder" on folders in Own filelist. The extension logs to the system log at startup whether the menu item registered successfully, failed, or was skipped — check that log line if the menu item doesn't appear.

Settings:
•	Default folder to scan — real disk path, used when /sfvcheck is typed without a path.
•	Number of release folders to process at once — default 8.
•	Only re-hash changed files — the incremental cache, on by default.
•	Clean up cache entries after (days) not seen — default 90.
•	Automatically delete files with a CRC mismatch — on by default.
•	Automatically redownload deleted (CRC mismatch) files — on by default.
•	Wait time (seconds) between automatic redownload searches — default 15.
•	Clean up the AirDC++ hash database after deleted files — on by default.
