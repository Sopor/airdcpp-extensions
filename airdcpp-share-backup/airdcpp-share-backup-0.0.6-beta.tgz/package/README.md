# airdcpp-share-backup

Adds a hub/private-chat command, `/sharebackup [path]`, that saves a
bzip2-compressed XML snapshot of your own share (folder names, file names,
sizes, TTH) to a local backup file. Optionally run automatically on
configurable days of the week, with automatic cleanup of old backups.

This is a backup of the file *listing* only, not the files themselves --
but it's the exact same XML format (and bzip2 compression) AirDC++ itself
uses for filelists, so the output is a real, valid `.xml.bz2` filelist you
could load in "Open own filelist" or "Open filelist" if you ever needed to.

## Commands

- `/sharebackup` -- back up your whole share right now.
- `/sharebackup <path>` -- back up just one virtual folder (and everything
  under it), e.g. `/sharebackup /Music/`.
- `/sharebackuphelp` -- show a short in-hub reminder of these commands and
  the current settings.

## Settings

- **Folder to save backups in** -- leave empty to use the extension's own
  log folder, under a `backups` subfolder. Each backup is saved as
  `<this folder>/YYYY-MM-DD/<nick>.<CID>.xml.bz2`.
- **Your AirDC++ nickname** -- must match your nick exactly as set in
  AirDC++ itself (Settings > Personal Information > Nick). Required:
  `/sharebackup` refuses to run until this is set.
- **Share profile ID to back up** -- leave at 0 to use your default share
  profile.
- **Skip these virtual folders** -- comma-separated folder names to leave
  out of the backup (matched anywhere in the tree).
- **Automatically back up on these days** -- comma-separated English day
  names, e.g. `monday` or `monday,thursday`. Empty by default, which
  disables automatic backups entirely (`/sharebackup` still always works
  manually). Checked once at startup and then hourly, so a missed day
  (AirDC++ was off) still runs once it's back on, but never more than once
  per calendar day.
- **Delete backups older than this many days** -- 0 disables cleanup.
  Checked after every backup, manual or automatic; removes whole dated
  folders, not individual files.

## Backup filenames

`<nick>.<CID>.xml.bz2`, e.g. `YourNick.D4I7FFUWQLQGGMUVSZJQG47AS3FNW7WD4SZD4VI.xml.bz2`
-- the exact naming convention AirDC++ itself uses for filelists, saved
inside a `YYYY-MM-DD` subfolder of the backup folder (e.g.
`2026-08-24/YourNick.D4I7FF....xml.bz2`). This is what makes the file
openable directly with AirDC++'s "Open filelist"; a differently-named file
is rejected with "invalid filelist name".

Since the filename itself can't carry a time or counter suffix without
breaking that recognition, there's one file per day: running a second
backup (manual or scheduled) on the same day overwrites that day's file
rather than creating a second one.

## How it works

This walks your share using AirDC++'s own stateless Share API (real disk
paths: `GET /share_roots` + `POST /share/directories/by_real/content`),
builds the filelist XML itself, and bzip2-compresses it in a worker thread
so the compression (which can take a few minutes on a large share, since
there's no native bzip2 module available to an extension) doesn't freeze
the connection to AirDC++.

Multiple real share roots added under the same virtual name are merged
into one folder, the same way AirDC++ merges them in its own filelist --
this is handled explicitly during the walk rather than relying on a
browsing session to do it.

### Why not AirDC++'s own `/generatelist`?

AirDC++ has a real, hidden hub command, `/generatelist`, that does this
same job natively and produces a genuine filelist in its own Settings
folder. It's confirmed by an AirDC++ developer and works when typed
directly into a hub's chat window.

Two earlier versions of this extension tried to use it instead of the
Share API, and both were tested against a real AirDC++ install:

- Using AirDC++'s "own filelist" browsing session API (the same thing
  "Open own filelist" uses) could get stuck retrying a directory that
  never became available, and corrupt the browsing session so every
  remaining folder failed too.
- Triggering `/generatelist` through the Web API's chat-message endpoint
  (both the per-hub and "all hubs" variants) is silently accepted --
  no error -- but never actually regenerates the file. Whatever maps the
  text `/generatelist` to the actual action appears to live only in the
  web UI's own client-side code, not anywhere an extension can reach over
  the WebSocket/REST API.

The Share API approach in this version has no session to corrupt and no
dependency on an undocumented, API-unreachable command -- every call is a
plain, independent request keyed by a real disk path, and it's fully
public, documented API surface.

## Building from source

```
npm install
npm run build
```

Produces `dist/main.js`. Copy this project's folder (with `dist/main.js`
and `package.json`) into your AirDC++ extensions folder, or zip it up the
way the packaged release is structured.
