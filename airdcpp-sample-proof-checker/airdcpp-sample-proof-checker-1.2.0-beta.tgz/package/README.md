airdcpp-sample-proof-checker (b1.2.0):

Checks release folders for missing Sample (with mkv) or Proof subfolders,
and searches/redownloads just that subfolder if needed.

Detects (via a manual scan through the context menu, /sampleproofcheck [path],
and automatically on every completed download):
•	Release folders split into .rar/.r00-style files
•	Within those: is the Sample folder missing, or does it contain no .mkv?
•	Within those: is the Proof folder missing?

Takes action on:
•	Sample missing/empty — searches specifically for <release name> Sample, and if a match is found, downloads only that subfolder into the existing release folder
•	Proof missing — same approach, searches specifically for <release name> Proof
•	Both present — nothing to do, moves straight on to the next folder

Automatic (post-download) retry, manual checks unaffected:
•	Only checks triggered by the completed-download hook use retry logic; /sampleproofcheck and the context menu still search immediately, once, no waiting.
•	retry_interval_minutes (default 60) — minutes to wait before the first automatic search, and between retries.
•	retry_max_hours (default 24, 0-168) — how long to keep retrying before giving up. 0 = try exactly once, immediately, no wait.
•	search_pause_seconds (default 20) — wait after starting a search before reading results.
•	overflow_backoff_seconds (default 60) — extra pause automatically applied after a "Search queue overflow" error.
•	restrict_to_share_folder — only run the AUTOMATIC (post-download) check within these virtual share folders (comma-separated, e.g. FiLMS,Series). Leave empty to check the whole share. Manual /sampleproofcheck and the context menu are never restricted by this.

Smart features:
•	Background searches use the lowest search priority (1), so manual searches/downloads always get sent to the hub first
•	One-at-a-time queue — prevents overloading/hanging AirDC++
•	A Sample/Proof folder is never itself treated as a release folder, so it can't trigger a search for its own Sample/Proof
•	Subs/Sub/SUBPACK folders are skipped
•	Excluded release groups configurable (default: CyTSuNee, SHiTSoNy)
•	Right-click "Check Sample/Proof for this folder" on your own file list, resolving to the exact real disk subfolder even when several real folders are merged under one virtual share name. The extension logs to the system log at startup whether the menu item registered successfully, failed, or was skipped — check that log line if the menu item doesn't appear.
•	Show messages in the system log — on by default.
•	Node.js DEP0169 deprecation warning suppressed.
