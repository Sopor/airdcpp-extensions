airdcpp-release-fixxer (b1.2.0, fork of the official release validator):

Scans downloaded and shared release directories for missing/extra files
(CRC/SFV/NFO) and automatically redownloads what's broken or missing.

Detects (via scan or automatically on new/completed downloads):
•	CRC errors (file does not match the .sfv)
•	Missing files (file_missing)
•	Missing SFV (sfv_missing)
•	Missing NFO (nfo_missing)
•	Broken/unreadable SFV — not a single valid line could be parsed from it (invalid_sfv_file)
•	Folders containing only an nfo/sfv but nothing else (no_release_files)
•	Plus the standard checks from the original validator: extra files, duplicate nfo/sfv, etc. — these are only reported, not fixed automatically, since "redownload" isn't a solution for those

Takes action on (CRC-redownload):
•	CRC error — the file is automatically deleted, after which the release folder is searched for and downloaded
•	Broken/unreadable SFV — the .sfv file itself is deleted first (otherwise "file already exists on disk" would block a new download of it), after which the release folder is searched for and downloaded
•	Missing file / SFV / NFO / no_release_files — the release folder is searched for and downloaded

Chat commands:
•	/rvalidator scan — scan the entire share
•	/rvalidator scan <path> — scan only that specific folder
•	/rvalidator help

Smart features:
•	Background redownload searches use the lowest search priority (1), so manual searches/downloads from the AirDC++ UI always get sent to the hub first
•	One-at-a-time queue — prevents "Search queue overflow"
•	Subs/Sub/SUBPACK folders: still searched, but no warning if nothing is found
•	Reports itself in the system log when AirDC++ starts, listing the available commands
•	Node.js DEP0169 deprecation warning suppressed; all other warnings still print normally

Settings: crc_delete_files, crc_redownload, crc_log_events (all on by default).

Works independently from airdcpp-sample-proof-checker, which specifically checks Sample/Proof subfolders. Works together with airdcpp-sfv-folder-checker: that extension writes a JSON report this extension can read, and it also detects CRC mismatches at the file level itself.
